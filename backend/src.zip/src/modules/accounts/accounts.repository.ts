import { and, asc, eq, isNull, ne } from "drizzle-orm";

import { db } from "../../db";
import { accounts } from "../../db/schema/accounts";

import type {
    AccountType,
    CreateAccountInput,
    UpdateAccountInput,
} from "./accounts.schema";

export class AccountsRepository {
    async create(userId: string, data: CreateAccountInput) {
        const [account] = await db
            .insert(accounts)
            .values({
                userId,
                name: data.name,
                type: data.type,
                openingBalance: data.openingBalance.toFixed(2),
                description: data.description,
                color: data.color,
                isDefault: data.isDefault ?? false,
            })
            .returning();

        return account;
    }

    async findById(userId: string, accountId: string) {
        const [account] = await db
            .select()
            .from(accounts)
            .where(
                and(
                    eq(accounts.id, accountId),
                    eq(accounts.userId, userId),
                    isNull(accounts.deletedAt),
                ),
            )
            .limit(1);

        return account ?? null;
    }

    async findAll(userId: string, archived?: boolean) {
        return db
            .select()
            .from(accounts)
            .where(
                and(
                    eq(accounts.userId, userId),
                    eq(accounts.isArchived, archived ?? false),
                    isNull(accounts.deletedAt),
                ),
            )
            .orderBy(asc(accounts.name));
    }

    async findByName(userId: string, name: string) {
        const [account] = await db
            .select()
            .from(accounts)
            .where(
                and(
                    eq(accounts.userId, userId),
                    eq(accounts.name, name),
                    isNull(accounts.deletedAt),
                ),
            )
            .limit(1);

        return account ?? null;
    }

    async findDuplicate(
        userId: string,
        accountId: string,
        name: string,
    ) {
        const [account] = await db
            .select()
            .from(accounts)
            .where(
                and(
                    ne(accounts.id, accountId),
                    eq(accounts.userId, userId),
                    eq(accounts.name, name),
                    isNull(accounts.deletedAt),
                ),
            )
            .limit(1);

        return account ?? null;
    }

    async clearDefault(userId: string) {
        await db
            .update(accounts)
            .set({
                isDefault: false,
                updatedAt: new Date(),
            })
            .where(
                and(
                    eq(accounts.userId, userId),
                    isNull(accounts.deletedAt),
                ),
            );
    }

    async update(
        userId: string,
        accountId: string,
        data: UpdateAccountInput,
    ) {
        const [account] = await db
            .update(accounts)
            .set({
                ...data,
                updatedAt: new Date(),
            })
            .where(
                and(
                    eq(accounts.id, accountId),
                    eq(accounts.userId, userId),
                    isNull(accounts.deletedAt),
                ),
            )
            .returning();

        return account ?? null;
    }

    async softDelete(
        userId: string,
        accountId: string,
    ) {
        const [account] = await db
            .update(accounts)
            .set({
                deletedAt: new Date(),
                updatedAt: new Date(),
            })
            .where(
                and(
                    eq(accounts.id, accountId),
                    eq(accounts.userId, userId),
                    isNull(accounts.deletedAt),
                ),
            )
            .returning();

        return account ?? null;
    }
    async getTotalBalance(userId: string) {
        const rows = await db
            .select({ openingBalance: accounts.openingBalance })
            .from(accounts)
            .where(
                and(
                    eq(accounts.userId, userId),
                    isNull(accounts.deletedAt),
                    eq(accounts.isArchived, false),
                ),
            );

        return rows.reduce((sum, r) => sum + Number(r.openingBalance ?? 0), 0);
    }

    async getAccountSummary(userId: string) {
        const totalBalance = await this.getTotalBalance(userId);
        const rows = await db
            .select({ id: accounts.id })
            .from(accounts)
            .where(and(eq(accounts.userId, userId), isNull(accounts.deletedAt), eq(accounts.isArchived, false)));

        return { totalBalance, count: rows.length };
    }

}

export const accountsRepository = new AccountsRepository();