import Fastify from "fastify";
import { authenticate } from "./middleware/auth";

export async function buildApp() {
    const app = Fastify({
        logger: true,
    });

    app.decorate("authenticate", authenticate);

    app.get("/", async () => {
        return {
            success: true,
            message: "Expense Tracker API",
        };
    });

    return app;
}